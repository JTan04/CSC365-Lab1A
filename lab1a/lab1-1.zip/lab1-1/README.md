# CSC365
# CSC365-Lab1A

Connor Alvin, Julian Tan, Michelle Jakab

To run our program, 
compile it with: javac schoolSearch.java
run it with: java schoolSearch

*students.txt must be in the same directory as the java program